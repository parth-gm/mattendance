	</div>
		<footer>
			<p>&copy; 2017 mAttendance. 
				<a href="http://ddit.ac.in" taget="_blank">
					<img src="images/ddu_logo.png" alt="DDU">
				</a>
			</p>
		</footer>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
  </body>
</html>