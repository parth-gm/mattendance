<div class="container">
  <div class="row">
    <div class="col-md-12 col-lg-12">
			<h1 class="page-header">Help (Manual)</h1>  
		</div>
	</div>
	
	<div class="row">
    <div class="col-md-12 col-lg-12">
			<h2>How Can I add Attendance?</h2>
			<p>Go to Take attendance page. Select subject and give specified date which you want to add Attendace.</p>
		</div>
	</div>
	
	<div class="row">
    <div class="col-md-12 col-lg-12">
			<h2>How Can I edit Attendance?</h2>
			<p>Go to Take attendance page. Select subject and give specified date which you want to update Attendace. It will list attendance record according. Change the attendance record and press Save attendance button. You are good to Go!</p>
			<p></p>
		</div>
	</div>
	
	<div class="row">
    <div class="col-md-12 col-lg-12">
			<h2>How Can I see Reports?</h2>
			<p>Go to Reports page. Select subject and specify the date range for which you want to see Reports. Click on load data. You are good to go!</p>
			<p></p>
		</div>
	</div>
	
	<div class="row">
    <div class="col-md-12 col-lg-12">
			<h2>How Can I see 5 Days ago Attendance Status?</h2>
			<p>Go to Dashboard and See in Previous Records pane. You can also see wether the attendance submitted or not.</p>
			<p></p>
		</div>
	</div>
	
	<div class="row">
    <div class="col-md-12 col-lg-12">
			<h2>How many Subjects are assigned to me?</h2>
			<p>Go to Dashboard and See in Previous Records / Todays's Attendance pane. Here you see your assigned subjects. You can also see total count of subject from You have pane.</p>
			<p></p>
		</div>
	</div>
	
	<div class="row">
    <div class="col-md-12 col-lg-12">
			<h2>How many Students are assigned to me?</h2>
			<p>Go to Dashboard and See You have pane. You can see the count of students you have with you.</p>
			<p></p>
		</div>
	</div>
	
</div>